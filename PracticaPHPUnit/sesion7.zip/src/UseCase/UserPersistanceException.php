<?php

namespace UseCase;

use Exception;

class UserPersistanceException extends Exception {
}