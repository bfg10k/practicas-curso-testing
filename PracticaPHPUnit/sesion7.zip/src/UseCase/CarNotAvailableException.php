<?php
namespace UseCase;

class CarNotAvailableException extends \Exception
{

}