<?php

namespace UseCase;


class MinorsCannotBookCarsException extends \Exception
{

}