<?php 

namespace Model;

class Booking {
    public function __construct(int $id, User $user, Car $car) {
        
    }
}