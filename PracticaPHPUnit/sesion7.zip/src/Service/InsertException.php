<?php


namespace Service;


use Exception;

class InsertException extends Exception
{
}