<?php declare(strict_types=1);
namespace Service;


class CarNotFoundException extends \Exception
{
}