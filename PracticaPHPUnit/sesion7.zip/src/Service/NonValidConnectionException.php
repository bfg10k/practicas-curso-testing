<?php

namespace Service;

use Exception;

class NonValidConnectionException extends Exception {
    
}