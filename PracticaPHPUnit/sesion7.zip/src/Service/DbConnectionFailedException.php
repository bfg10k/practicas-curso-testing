<?php declare(strict_types=1);

namespace Service;

use Exception;

class DbConnectionFailedException extends Exception
{
}