<?php

namespace Test\Unit\UserController;

use Controller\UserController;

class UserControllerTestClass extends  UserController
{

}